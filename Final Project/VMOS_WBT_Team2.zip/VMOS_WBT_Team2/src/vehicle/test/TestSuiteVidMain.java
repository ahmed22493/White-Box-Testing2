package vehicle.test;

import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.SelectClasses;
import org.junit.runner.RunWith;

@RunWith(JUnitPlatform.class)
@SelectClasses ({TestVidMain.class})

 class TestSuiteVidMain {

	@Test
	public void test()
	{

	}

}
