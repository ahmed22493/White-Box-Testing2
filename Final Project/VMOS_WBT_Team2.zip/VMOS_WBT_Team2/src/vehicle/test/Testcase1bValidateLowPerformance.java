package vehicle.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import vehicle.app.State;
import vehicle.hal.Temp;

class Testcase1bValidateLowPerformance {
	State StateObj= new State();
	
	/*********************************************************************************************
	 * Test Case (1) 																			 *
	 * Objective : Verify that:																	 *
	 * 			   1- Temp.iReadT1() is called once												 *
	 * 			   2- Temp.iReadT2() is called once												 *
	 * 			   3- The function return true in case of Temp.iReadT1()<60 && Temp.iReadT2()>50 *
	 * 			   4- The Temp.iReadT1()<60 condition is identified and executed --> (True)		 *	
	 * 			   5- The Temp.iReadT2()>50 condition is identified and executed --> (True)		 *																				 *		
	 * *******************************************************************************************/
	 
	@Test
	void test() {
		Temp.tag = 3;
		Temp.validedcalliRead1=0;
		Temp.validedcalliRead2=0;
		boolean Check = StateObj.bValidateLowPerformance();
		assertAll(
					()->assertTrue(Check),
					()->assertEquals(1,Temp.validedcalliRead1,"ValidateCallR1"),
					()->assertEquals(1,Temp.validedcalliRead2,"ValidateCallR2"),
					()->assertTrue(Temp.iReadT1()<60,"ValidateCondition1"),
					()->assertTrue(Temp.iReadT2()>50,"ValidateCondition2") 
				);
	}

}
