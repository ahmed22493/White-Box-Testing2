package vehicle.test;

import org.junit.runner.*;

public class TestRunner1 {
	
	public static void main (String []args) {
	Result result = JUnitCore.runClasses(TestSuiteVidMain.class,
			TestSuitebValidateFailure.class,
			TestSuitebValidateLowPerformance.class);	
	
	
	System.out.println("Total number of excuted test cases are: "+(result.getRunCount()-3)); 
	System.out.println("Total number of failed test cases are: "+result.getFailureCount());
	System.out.println("The failures are: "+result.getFailures());
	System.out.println("The state of TestRunner is: "+result.wasSuccessful());

	}
	

}
