package vehicle.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import vehicle.app.State;
import vehicle.hal.Temp;

class Testcase3bValidateLowPerformance {
	State StateObj= new State();
	/**********************************************************************************************
	 * Test Case (3) 																			  *
	 * Objective : Verify that:																	  *
	 * 			   1- Temp.iReadT1() is called once												  *
	 * 			   2- Temp.iReadT2() is called never called					     				  * 
	 * 			   3- the sequence started by Temp.iReadT1() then Temp.iReadT2() as in SDD	      *
	 * 			   4- The function return False in case of Temp.iReadT1()<60 && Temp.iReadT2()>50 *
	 * 			   5- The Temp.iReadT1()<60 condition is identified and executed --> (False)	  *	
	 * ********************************************************************************************/
	@Test
	void test() {
		Temp.tag = 5;
		Temp.validedcalliRead1=0;
		Temp.validedcalliRead2=0;
		boolean Check = StateObj.bValidateLowPerformance();
		assertAll(
					()->assertFalse(Check),
					()->assertEquals(1,Temp.validedcalliRead1,"ValidateCallR1"),
					()->assertEquals(0,Temp.validedcalliRead2,"ValidateCallR2"),
					()->assertEquals(1,Temp.validedseq,"ValidateSeq"),
					()->assertFalse(Temp.iReadT1()<60,"ValidateCondion") 
				);
		
	}

}
