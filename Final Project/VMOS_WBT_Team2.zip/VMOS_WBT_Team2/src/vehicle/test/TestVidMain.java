package vehicle.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import vehicle.app.Main;
import vehicle.app.State;
import vehicle.hal.LCD;
import vehicle.hal.Motor;

class TestVidMain {

	/*********************************************************************************************
	 * Test Case (1) 																			 *
	 * Objective : Verify that:																	 *
	 * 			   1- LCD.vidOutput() is called once											 *
	 * 			   2- Motor.vidOutput() is called once											 *
	 * 			   3- state.vidGoToNextState() is called once 									 *
	 * 			   4- This function shall call the three functions in sequence		     		 *	
	 * *******************************************************************************************/
	@Test
	void test() {
		Main.vidMain();
		assertAll(	
				()-> assertEquals(1,LCD.LCD_ValidateCall,"LCD ValidateCall"),
				()-> assertEquals(1,State.state_ValidateCall,"State ValidateCall"),
				()-> assertEquals(1,Motor.Motor_ValidateCall,"Motor ValidateCall"),
				()-> assertEquals(3,State.ValidateSeq,"ValidateSeq"));
	             }


}
