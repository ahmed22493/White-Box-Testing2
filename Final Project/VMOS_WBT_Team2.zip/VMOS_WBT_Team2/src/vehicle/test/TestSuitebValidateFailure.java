package vehicle.test;

import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.SelectClasses;
import org.junit.runner.RunWith;



@RunWith (JUnitPlatform.class)
@SelectClasses ({Testcase1bValidateFailure.class,Test1bValidateFailurre.class})
class TestSuitebValidateFailure {

	@Test
	public void test() {

	}

}
