package vehicle.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import vehicle.app.State;
import vehicle.hal.Temp;

class Testcase1bValidateFailure {

	Boolean result;
	State stateobj = new State();


	/*********************************************************************************************
	 * Test Case (1) 																			 *
	 * Objective : Verify that:																	 *
	 * 			   1- Temp.iReadT1() is called once												 *
	 * 			   2- Temp.iReadT2() is called once												 *
	 * 			   3- The function return true in case of Temp.iReadT1() != Temp.iReadT2()		 *
	 * 			   4- The ( Temp.iReadT1() != Temp.iReadT2() ) decision is identified and		 *
 	 *				  executed --> (True)														 *	
	 * *******************************************************************************************/
	@Test
	void test1() {
		Temp.tag = 1 ;
		Temp.ValidateCallT1 = 0;
		Temp.ValidateCallT2 = 0;
		 result = stateobj.bValidateFaliure();
			assertAll(	
					()-> assertEquals(1,Temp.ValidateCallT1,"ValidatecallT1"),
					()-> assertEquals(1,Temp.ValidateCallT2,"ValidateCallT2"),
					()-> assertEquals(true, result,"Validate Return"),
					()-> assertTrue(Temp.iReadT1() != Temp.iReadT2(),"ValidateCondition") 
					);
	}
}
