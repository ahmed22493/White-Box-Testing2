package vehicle.hal;

public class Temp {
	
	public static int ValidateCallT1 = 0;
	public static int ValidateCallT2 = 0;
	public static int validedcalliRead1=0 ;
	public static int validedcalliRead2=0 ;
	public static int validedseq=0 ;
	public static int tag;
	
	public static int iReadT1()
	{ 
		int ret=0;
		validedcalliRead1 ++;
		validedseq=1 ;
		ValidateCallT1++;
		
		if (tag == 1)
		{
			ret = 10;
		}
		else if (tag == 2)
		{
			ret = 20;
		}
		
		else if(tag == 3)
		{
			ret= 30;
		}
		
		else if (tag==4)
		{
			ret= 30;		
		}
		
		else if (tag==5)
		{
			ret= 70;		
		}
		
		return ret;
	}
	
	public static int iReadT2()
	{
		int ret=0;
		ValidateCallT2++;
		validedcalliRead2 ++ ;
		validedseq=2 ;
		if (tag == 1)
		{
			ret = 20;
		}
		else if (tag == 2)
		{
			ret = 20;
		}
		
		else if(tag==3)
		{
			ret= 70;
		}
		else if (tag==4)
		{
			ret= 30;		
		}
		else if (tag==5)
		{
			ret = 70;
		}
		return ret ;
	}
}
