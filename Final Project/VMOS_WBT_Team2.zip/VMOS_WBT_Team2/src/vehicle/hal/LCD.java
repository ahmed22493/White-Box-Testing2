package vehicle.hal;

import vehicle.app.State;

public class LCD {
	public static int LCD_ValidateCall= 0;
	public static void vidOutput(int state)
	{
		LCD_ValidateCall++;
		State.ValidateSeq++;
	}
}
