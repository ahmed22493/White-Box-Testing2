package vehicle.hal;

import vehicle.app.State;

public class Motor {
	public static int Motor_ValidateCall= 0;
	public static void vidOutput(int state)
	{
		Motor_ValidateCall++;
		State.ValidateSeq++;
	}
}
