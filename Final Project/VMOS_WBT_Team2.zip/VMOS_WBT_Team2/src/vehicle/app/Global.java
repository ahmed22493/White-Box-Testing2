package vehicle.app;

public class Global {
	public static int iState;
}
