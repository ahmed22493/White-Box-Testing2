package vehicle.app;

import vehicle.hal.Temp;

public class State {
	
	public static int state_ValidateCall = 0;
	public static int ValidateSeq= 0;
	//we need to test this function 4 remooooooooooooooove
	public boolean bValidateFaliure()
	{
		if (Temp.iReadT1() !=Temp.iReadT2())
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	
	
	public void vidGoToNextState()
	{
		ValidateSeq++;
		state_ValidateCall++;
		
	}
	
	
	// we need to test this function
		public boolean bValidateLowPerformance()
		{
			if( (Temp.iReadT1()<60) && (Temp.iReadT2()>50) )
			{
				return true;
			}else
				{
					return false ;
				}
		}


	
	
	
	
	

 
 
}
